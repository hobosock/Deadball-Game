close all; clear all; clc;

%% user inputs
era = 'modern'; % 'modern' or 'ancient'
% roster numbers are based on normal/default for MLB with pinch hitters accounting for backup position players
starting_hitters = 8; % 8 by default
pinch_hitters = 5; % 5 by default
starting_pitchers = 5; % 5 by default
relievers = 7; % 7 by default

%% FRANCHISE
% initialize some stuff
FB = 0;
quirks = 0;
turf = 0;
roof = 0;

disp('FRANCHISE DETAILS')
% location
loc = randi(1,20);
if loc == 1
    location = 'middle of nowhere';
    FB = FB - 2;
elseif loc >= 2 && loc <= 4
    location = 'small town';
    FB = FB - 1;
elseif loc >= 5 && loc <= 9
    location = 'small city';
elseif loc >= 10 && loc <= 14
    location = 'medium city';
    FB = FB + 1;
else
    location = 'metropolis';
    FB = FB + 2;
end
disp(['Location: ', location])

% team priority
if strcmp (era,'modern')
    pri = randi(1,20);
elseif strcmp(era,'ancient')
    pri = randi(1,20) + 5;
else
    disp('Era not recognized.  Enter either "modern" or "ancient" in lowercase.  Check spelling.')
end

if pri <= 5
    priority = 'hitting for power';
elseif 6 <= pri && pri <= 10
    priority = 'hitting for average';
elseif 11 <= pri && pri <= 15
    priority = 'starting pitching';
elseif pri == 16
    priority = 'bullpen';
elseif 17 <= pri && pri <= 18
    priority = 'speed';
else
    priority = 'defense';
end
disp(['Team priority: ', priority])

% team makeup
mak = randi(1,20);
if mak <=5
    makeup = 'mostly prospects';
elseif 6 <= mak && mak <= 15
    makeup = 'balanced';
else
    makeup = 'mostly veterans';
end
disp(['Team makeup: ', makeup])

% recent championship
champ = randi(1,20);
if champ == 1;
    championship = 'last season';
    FB = FB + 3;
elseif 2 <= champ && champ <= 3
    championship = '2-4 years ago';
    FB = FB + 2;
elseif 4 <= champ && champ <= 8
    championship = '5-9 years ago';
    FB = FB + 1;
elseif 9 <= champ && champ <= 15
    championship = '10-24 years ago';
elseif 16 <= champ && champ <= 19
    championship = '25-49  years ago';
    FB = FB - 1;
else
    championship = '50 or more years ago';
    FB = FB - 2;
end
disp(['Most recent championship: ', championship])
            
% mascot
mas = randi(1,20);
if mas == 1
    mascot = 'demonym (Baltimorean, Honolulan)';
elseif mas == 2
    mascot = 'local nickname (Hawkeye, Hoosier)';
elseif mas == 3
    mascot = 'geography (Lakesiders, Canyons)';
elseif mas == 4
    mascot = 'weather (Twisters, Wintry Mixes)';
elseif mas == 5
    mascot = 'industry (Butchers, Bakers)';
elseif mas == 6
    mascot = 'bird (Robins, Herons, Swallows)';
elseif mas == 7
    mascot = 'fish (Guppies, Catfish, Tilapia)';
elseif mas == 8
    mascot = 'predator (Pumas, Hyenas, Humans)';
elseif mas == 9
    mascot = 'horse (Palaminos, Appaloosas, Pintos)';
elseif mas == 10
    mascot = 'gentle Animal (Manatees, Big Birds)';
elseif mas == 11
    mascot = 'mytholocigal Creature (Gryffons, yeti)';
elseif mas == 12
    mascot = 'color (Blues, Yellows, Purples)';
elseif mas == 13
    mascot = 'clothing (Blue Sox, White Caps)';
elseif mas == 14
    mascot = 'baseball term (curveballs, heaters)';
elseif mas == 15
    mascot = 'food (Beefsteaks, Waffles, Biscuits)';
elseif mas == 16
    mascot = 'historical figure (Hamiltons, Burrs)';
elseif mas == 17
    mascot = 'noble title (Dukes, Viscounts, Barons)';
elseif mas == 18
    mascot = 'military ranks (Admirals, Generals)';
elseif mas == 19
    mascot = 'weapons (Cutlasses, Knuckledusters)';
elseif mas == 20
    mascot = 'random word (Gasconades, Turnkeys)';
end
disp(['Mascot: ', mascot])

% years in league
year = randi(1,20);
if year == 1
    years = 'expansion';
    FB = FB + 2;
elseif year == 2
    years = '1-4 years';
    FB = FB + 1;
elseif 3 <= year && year <= 4
    years = '5-9 years';
elseif 5 <= year && year <= 6
    years = '10-19 years';
elseif 7 <= year && year <= 8
    years = '20-29 years';
elseif 9 <= year && year <= 10
    years = '30-39 years';
elseif 11 <= year && year <= 12
    years = '40-49 years';
elseif 13 <= year && year <= 14
    years = '50-75 years';
    FB = FB + 1;
elseif 15 <= year && year <= 20
    years = 'since league founding';
    FB = FB +2;
end
disp(['Years in league: ', years])

%% Owner details
disp('OWNER DETAILS')
% owner background
ownback = randi(1,20);
if ownback == 1
    owner_background = 'captain of industry';
elseif ownback == 2
    owner_background = 'eccentric inventor';
elseif ownback == 3
    owner_background = 'entertainer';
elseif ownback == 4
    owner_background = 'former player';
elseif ownback == 5
    owner_background = 'heir to previous owner';
elseif ownback == 6
    owner_background = 'local government';
elseif ownback == 7
    owner_background = 'local magnate)';
elseif ownback == 8
    owner_background = 'media personality';
elseif ownback == 9
    owner_background = 'millionaire recluse';
elseif ownback == 10
    owner_background = 'multinational corporation';
elseif ownback == 11
    owner_background = 'newspaper syndicate';
elseif ownback == 12
    owner_background = 'oil man';
elseif ownback == 13
    owner_background = 'players cooperative';
elseif ownback == 14
    owner_background = 'politician';
elseif ownback == 15
    owner_background = 'railroad baron';
elseif ownback == 16
    owner_background = 'real estate developer';
elseif ownback == 17
    owner_background = 'riverboat gambler';
elseif ownback == 18
    owner_background = 'roller coaster tycoon';
elseif ownback == 19
    owner_background = 'venture capitalist';
elseif ownback == 20
    owner_background = 'war hero';
end
disp(['Owner background: ', owner_background])

% owner personality
ownper = randi(1,20);
if ownper == 1
    owner_personality = 'baffled';
elseif ownper == 2
    owner_personality = 'boastful';
elseif ownper == 3
    owner_personality = 'combative';
elseif ownper == 4
    owner_personality = 'cowardly';
elseif ownper == 5
    owner_personality = 'destructive';
elseif ownper == 6
    owner_personality = 'elegant';
elseif ownper == 7
    owner_personality = 'even-keeled';
elseif ownper == 8
    owner_personality = 'giddy';
elseif ownper == 9
    owner_personality = 'gossipy';
elseif ownper == 10
    owner_personality = 'gregarious';
elseif ownper == 11
    owner_personality = 'hedonistic';
elseif ownper == 12
    owner_personality = 'humble';
elseif ownper == 13
    owner_personality = 'lovable';
elseif ownper == 14
    owner_personality = 'miserly';
elseif ownper == 15
    owner_personality = 'noble';
elseif ownper == 16
    owner_personality = 'quixotic';
elseif ownper == 17
    owner_personality = 'sadistic';
elseif ownper == 18
    owner_personality = 'slovenly';
elseif ownper == 19
    owner_personality = 'temperamental';
elseif ownper == 20
    owner_personality = 'unbalanced';
end
disp(['Owner personality: ', owner_personality])

%% BALLPARK
disp('BALLPARK DETAILS')
% park name
if strcmp(era,'ancient')
    park = randi(1,20) - 2;
elseif strcmp(era,'modern')
    park = randi(1,20);
else
    disp('Era not recognized.  Enter either "modern" or "ancient" in lowercase.  Check spelling.')
end
if park <= 4
    park_name = 'city (Buffalo Ballpark, Yuma Yards)';
elseif 5 <= park && park <= 9
    park_name = 'geography (Butte Park, Bayou Dome)';
elseif 10 <= park && park <= 12
    park_name = 'owner (Wood Park, Burke Grounds)';
elseif 13 <= park && park <= 15
    park_name = 'player (Riblet Grounds, Ellis Ballpark)';
else
    park_name = 'sponser (Corinthian Bank Park)';
end
disp(['Park name: ', park_name])

% park location
if strcmp(era,'ancient')
    ploc = randi(1,10);
elseif strcmp(era,'modern')
    ploc = randi(1,20);
else
    disp('Era not recognized.  Enter either "modern" or "ancient" in lowercase.  Check spelling.')
end
if ploc <= 3
    park_location = 'decrepit downtown';
    FB = FB - 1;
elseif 4 <= ploc && ploc <= 6
    park_location = 'bustling downtwon';
    FB = FB + 1;
elseif 7 <= ploc && ploc <= 9
    park_location = 'riverfront';
elseif ploc == 10
   park_location = 'mountaintop';
elseif 11 <= ploc && ploc <= 15
   park_location = 'suburbs';
  FB = FB - 1;
else
    park_location = 'revived downtown'
    FB = FB + 1;
end
disp(['Park location: ', park_location])

% stadium type
if strcmp(era,'ancient')
    stad = randi(1,20)
    if stad <= 10
        stadium = 'wood frame pavilion';
        capacity = 5000 + randi(1,10)*1000;
        quirks = quirks + 2;
    elseif 11 <= stad && stad <= 19
        stadium = 'jewel box';
        capacity = 35000 + randi(1,10)*1000;
        quirks = quirks + 1;
        FB = FB + 1;
    else
        stadium = 'baseball palace';
        capacity = 50000 + randi(1,10)*1000;
        FB = FB + 2;
    end
elseif strcmp(era,'modern')
    stad = randi(1,20);
    if stad <=3
        stadium = 'jewel box';
        capacity = 35000 + randi(1,10)*1000;
        quirks = quirks + 1;
        FB = FB + 1;
    elseif 4 <= stad && stad <= 5
        stadium = 'baseball palace';
        capacity = 50000 + randi(1,10)*1000;
        FB = FB + 2;
    elseif 6 <= stad && stad <= 10
        stadium = 'space age';
        capacity = 50000 + randi(1,10)*1000;
        roof = 1;
    elseif 11 <= stad && stad <= 14
        stadium = 'concrete donut';
        capacity = 55000 + randi(1,10)*1000;
        turf = 1;
        FB = FB - 1;
        roof = 1;
    else
        stadium = 'retro';
        capacity = 38000 + randi(1,10)*1000;
        quirks = quirks + 1;
        roof = 1;
    end
end
disp(['Stadium type: ', stadium])
disp(['Capacity: ', num2str(capacity)])

% turf
if turf == 1
    turf_roll = randi(1,20);
    if turf_roll <= 2
        turf_condition = 'ragged';
        turf_mod = '-1 to steal and infield defense';
    elseif 3 <= turf_roll && turf_roll <= 10
        turf_condition = 'good';
        turf_mod = 'none';
    else
        turf_condition = 'artificial';
        turf_mod = '+1 to steal and infield DEF';
    end
    disp(['Turf: ', turf_condition])
end

% roof
if roof == 1
    roof_roll = randi(1,20);
    if roof_roll <= 13
        roof_condition = 'no roof';
    elseif 14 <= roof && roof <= 15
        roof_condition = 'permanent roof';
    else
        roof_condition = 'retractable roof';
    end
    disp(['Roof: ', roof_condition])
end

% condition
if strcmp(era,'ancient')
    pcon = randi(1,20) - 1;
elseif strcmp(era,'modern')
    pcon = randi(1,20);
end
if pcon == 0
    condition = 'falling apart';
    FB = FB - 3;
elseif 1 <= pcon && pcon <= 6
    condition = 'decrepit';
    FB = FB - 2;
elseif 7 <= pcon && pcon <= 15
    condition = 'well-worn';
else
    condition = 'sparkling';
    FB = FB + 2;
end
disp(['Condition: ', condition])

% quirks
for i = 1:length(quirks)
    qui = randi(1,20);
    if qui <= 3
        quirk{i} = 'cozy outfield';
        quirk_effect{i} = 'Add 1 to all Hit Table rolls, except when doing so will reduce result.';
    elseif 4 <= qui && qui <= 6
        quirk{i} = 'expansive outfield';
        quirk_effect{i} = 'Subtract 1 from all Hit Table rolls, except when doing so will improve result.';
    elseif qui == 7
        quirk{i} = 'short left field porch';
        quirk_effect{i} = 'An MSS of 47 or 57 is a home run.';
    elseif qui == 8
        quirk{i} = 'short right field porch';
        quirk_effect{i} = 'An MSS of 49 or 59 is a home run.';
    elseif qui == 9
        quirk{i} = 'left field oddity';
        quirk_effect{i} = 'Subtract 1 from all LF DEF rolls made by away team.';
    elseif qui == 10
        quirk{i} = 'center field oddity';
        quirk_effect{i} = 'Subtract 1 from all CF DEF rolls made by away team.';
    elseif qui == 11
        quirk{i} = 'right field oddity';
        quirk_effect{i} = 'Subtract 1 from all RF DEF rolls made by away team.';
    elseif qui == 12
        quirk{i} = 'fast infield';
        quirk_effect{i} = 'Add 1 to all stolen base rolls.  Subtract 1 from all infield DEF rolls.';
    elseif qui == 13
        quirk{i} = 'slow infield';
        quirk_effect{i} = 'Subtract 1 from all stolen base rolls.  Add 1 to all infield DEF rolls.';
    elseif qui == 14
        quirk{i} = 'high mound';
        quirk_effect{i} = 'Add 1 to every MSS';
    elseif 15 <= qui && qui <= 17
        quirk{i} = 'beautiful';
        quirk_effect{i} = 'Add 1 to Fanbase roll (taken care of in tool)';
        FB = FB + 1;
    else
        quirk{i} = 'hideous';
        quirk_effect{i} = 'Subtract 1 from Fanbase roll (taken care of in tool)';
        FB = FB - 1;
    end
end
for i = 1:length(quirks)
    disp(['Quirk: ', quirk{i}])
    disp(['Effect: ', quirk_effect{i}])
end

%% manager
disp(['MANAGER DETAILS'])
manpos = randi(1,20);
if manpos == 1
    position = 'pitcher (majors)';
elseif manpos == 2
    position = 'pitcher (minors)';
elseif manpos == 3
    position = 'catcher (majors)';
elseif manpos == 4
    position = 'catcher (minors)';
elseif manpos == 5
    position = 'first base (majors)';
elseif manpos == 6
    position = 'first base (minors)';
elseif manpos == 7
    position = 'second base (majors)';
elseif manpos == 8
    position = 'second base (minors)';
elseif manpos == 9
    position = 'third base (majors)';
elseif manpos == 10
    position = 'third base (minors)';
elseif manpos == 11
    position = 'shortstop (majors)';
elseif manpos == 12
    position = 'shortstop (minors)';
elseif manpos == 13
    position = 'left field (majors)';
elseif manpos == 14
    position = 'left field (minors)';
elseif manpos == 15
    position = 'center field (majors)';
elseif manpos == 16
    position = 'center field (minors)';
elseif manpos == 17
    position = 'right field (majors)';
elseif manpos == 18
    position = 'right field (minors)';
else
    position = 'never played';
end
disp(['Manager position: ', position])
manper = randi(1,20);
if manper == 1
    manager_personality = 'apathetic';
elseif manper == 2
    manager_personality = 'charming';
elseif manper == 3
    manager_personality = 'colorless';
elseif manper == 4
    manager_personality = 'dignified';
elseif manper == 5
    manager_personality = 'domineering';
elseif manper == 6
    manager_personality = 'dull';
elseif manper == 7
    manager_personality = 'fatalistic';
elseif manper == 8
    manager_personality = 'fiery';
elseif manper == 9
    manager_personality = 'fun-loving';
elseif manper == 10
    manager_personality = 'gloomy';
elseif manper == 11
    manager_personality = 'imaginative';
elseif manper == 12
    manager_personality = 'loyal';
elseif manper == 13
    manager_personality = 'open';
elseif manper == 14
    manager_personality = 'polite';
elseif manper == 15
    manager_personality = 'rude';
elseif manper == 16
    manager_personality = 'sincere';
elseif manper == 17
    manager_personality = 'taciturn';
elseif manper == 18
    manager_personality = 'thin-skinned';
elseif manper == 19
    manager_personality = 'tough';
elseif manper == 20
    manager_personality = 'vain';
end
disp(['Manager personality: ', manager_personality])
ret = randi(1,20);
if ret == 20
    ret = ret + randi(1,20);
end
disp(['Manager retired ', num2str(ret), ' years ago.'])
daring = randi(1,20);
disp(['Daring: ', num2str(daring)])

%% fanbase
fb = randi(1,20) + FB;
if fb <= 2
    fanbase = 'Non-existent: 20% attendance.  Team is broke.';
elseif 3 <= fb && fb <= 5
    fanbase = 'Indifferent: 35% attendance.  Team is struggling.';
elseif 6 <= fb && fb <= 10
    fanbase = 'Fair Weather: 50% attendance.  Team is breaking even.';
elseif 11 <= fb && fb <= 18
    fanbase = 'Loyal: 75% attendance.  Team is prospering.';
else
    fanbase = 'Obsessive: 100% attendance.  team is printing money.  Add quirk "Home Field Advantage", which grants 1 re-roll per home game, or 2 for ballparks with a roof.';
end

%% Player Generation
% starting hitters
shcell = {};
for i = 1:starting_hitters
    BT = 15 + randi(1,10) + randi(1,10);
    WT = BT + randi(1,6) + randi(1,6);
    hand_roll = randi(1,10);
    if hand_roll <= 6
        hand = 'R';
    elseif 7 <= hand_roll && hand_roll <= 9
        hand = 'L';
    else
        hand = 'S';
    end
    hc_roll = randi(1,6);
    if hc_roll == 1
        streak = 'cold';
    elseif 2 <= hc_roll && hc_roll <= 5
        streak = 'none';
    else
        streak = 'hot';
    end
    trait_roll = randi(1,6) + randi(1,6);
    if trait_roll == 2
        traits = [4, 5];
    elseif trait_roll == 3
        traits = 4;
    elseif trait_roll == 4
        traits = 5;
    elseif 5 <= trait_roll && trait_roll <= 9
        traits = 0;
    elseif trait_roll == 10
        traits = 1;
    elseif trait_roll == 11
        traits = 3;
    else
        traits = 2;
    end
    age1 = randi(1,20);
    if age1 <= 5 % prospect
        age = 18 + randi(1,6);
    elseif 6 <= age1 && age1 <= 12
        age = 21 + randi(1,6);
    elseif 13 <= age1 && age1 <= 18
        age = 26 + randi(1,6);
    else
        age = 34 + randi(1,6);
    end
    shcell{i,1} = BT;
    shcell{i,2} = WT;
    shcell{i,3} = hand;
    shcell{i,4} = streak;
    shcell{i,5} = traits;
    shcell{i,6} = NaN;
    shcell{i,7} = age;
end
c = 0;
b1 = 0;
b2 = 0;
ss = 0;
b3 = 0;
rf = 0;
cf = 0;
lf = 0;
% attempt to assign starting hitter positions

% pinch hitters
phcell = {};
for i = 1:pinch_hitters
    BT = 15 + randi(1,10);
    WT = BT + randi(1,6) + randi(1,6);
    hand_roll = randi(1,10);
    if hand_roll <= 6
        hand = 'R';
    elseif 7 <= hand_roll && hand_roll <= 9
        hand = 'L';
    else
        hand = 'S';
    end
    trait_roll = randi(1,6) + randi(1,6);
    if trait_roll == 2
        traits = 4;
    elseif trait_roll == 3
        traits = 3;
    elseif 4 <= trait_roll && trait_roll <= 10
        traits = 0;
    elseif trait_roll == 11
        traits = 5;
    else
        traits = 1;
    end
    age1 = randi(1,20);
    if age1 <= 5 % prospect
        age = 18 + randi(1,6);
    elseif 6 <= age1 && age1 <= 12
        age = 21 + randi(1,6);
    elseif 13 <= age1 && age1 <= 18
        age = 26 + randi(1,6);
    else
        age = 34 + randi(1,6);
    end
    streak = 'none';
    phcell{i,1} = BT;
    phcell{i,2} = WT;
    phcell{i,3} = hand;
    phcell{i,4} = streak;
    phcell{i,5} = traits;
    phcell{i,6} = NaN;    
    phcell{i,7} = age;
end
% pitchers
pcell = {};
for i = 1:(starting_pitchers + relievers)
    pd = randi(1,8);
    if pd == 1
        pitch_die = 'd12';
    elseif pd == 2 || pd == 3
        pitch_die = 'd8';
    elseif 4 <= pd && pd <= 6
        pitch_die = 'd4';
    else
        pitch_die = '-d4';
    end
    hand_roll = randi(1,10);
    if hand_roll <= 6
        hand = 'R';
    else
        hand = 'L';
    end
    BT = 5 + randi(1,10);
    WT = BT + randi(1,6) + randi(1,6);
    trait_roll = randi(1,6) + randi(1,6);
    if trait_roll == 2
        traits = [6, 11];
    elseif trait_roll == 3
        traits = [6, 12];
    elseif 4 <= trait_roll && trait_roll <= 10
        traits = 6;
    elseif trait_roll == 11
        traits = [6, 13];
    else
        traits = [6, 14];
    end
    age1 = randi(1,20);
    if age1 <= 5 % prospect
        age = 18 + randi(1,6);
    elseif 6 <= age1 && age1 <= 12
        age = 21 + randi(1,6);
    elseif 13 <= age1 && age1 <= 18
        age = 26 + randi(1,6);
    else
        age = 34 + randi(1,6);
    end
    streak = 'none';
    pcell{i,1} = BT;
    pcell{i,2} = WT;
    pcell{i,3} = hand;
    pcell{i,4} = streak;
    pcell{i,5} = traits;
    pcell{i,6} = pitch_die;    
    pcell{i,7} = age;
end
    