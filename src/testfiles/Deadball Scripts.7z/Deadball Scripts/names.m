filename = 'C:\Users\Seth Loveall\Downloads\baseballdatabank-master\baseballdatabank-master\core\People.csv';
pkg load io
people = csv2cell(filename);
first_name = people(2:end,14);
last_name = people(2:end,15);
destination = 'M:\Documents\Deadball Scripts';
filename2 = 'firstname.csv';
cell2csv([destination '\' filename2],first_name)
filename3 = 'lastname.csv';
cell2csv([destination '\' filename3],last_name)