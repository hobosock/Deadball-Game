## Copyright (C) 2020 Seth
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} namegen (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: Seth <Seth@DESKTOP-0JBTD7P>
## Created: 2020-06-11

function names = namegen (num)
pkg load io
firstnames = csv2cell('firstname.csv');
lastnames = csv2cell('lastname.csv');
names = {};
for i = 1:num
  firstnum = randi([1 length(firstnames)]);
  lastnum = randi([1 length(lastnames)]);
  first = firstnames{firstnum};
  last = lastnames{lastnum};
  names{i} = [first ' ' last];
end
names = names';
endfunction
