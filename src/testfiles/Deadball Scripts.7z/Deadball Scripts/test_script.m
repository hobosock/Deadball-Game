c = 0;
b1 = 0;
b2 = 0;
ss = 0;
b3 = 0;
rf = 0;
cf = 0;
lf = 0;
% attempt to assign starting hitter positions
temp = find(cell2mat(shcell(:,5))==10); % find bad defenders and stick them in the outfield (or first base)
pos_assign = {'LF','RF','1B'};
if ~isempty(temp)
  for i = 1:length(temp)
    if i >= 4
      break
    end    
    shcell{temp(i),9} = pos_assign{i};
    if i == 1
      lf = 1;
    end
    if i == 2
      rf = 1;
    end
    if i == 3
      b1 = 1;
    end    
  end
end